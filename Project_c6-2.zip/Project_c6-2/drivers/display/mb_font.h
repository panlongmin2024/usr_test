/*
 * Copyright (c) 2017 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#define MB_FONT_COUNT 95
#define MB_FONT_START ' '
#define MB_FONT_END   '~'

extern const struct mb_image mb_font[MB_FONT_COUNT];
